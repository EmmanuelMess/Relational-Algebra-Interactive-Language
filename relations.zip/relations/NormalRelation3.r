RelationC
AA(S)    BB(I) CC(F) DD(I) EE(I)
"No"     1    2.0  3    1000
"Nop"    1    2.0  3    1000
"Not"    1    2.0  3    1000