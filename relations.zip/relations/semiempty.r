Semiempty
A(I) B(F) C(S)