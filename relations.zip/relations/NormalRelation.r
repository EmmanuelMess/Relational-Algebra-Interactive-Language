Relation
A(S)     B(I) C(F) D(I) E(I)
"Nombre" 1    2.0  3    5
"Nombre" 2    2.0  3    6
"Nombre" 3    2.0  3    7
"Nombre" 4    2.0  3    7
"Nombre" 5    N  3    9
"Nombre" 6    2.0  3    10
"Nombre" 7    2.0  3    11
"Nombre" 8    2.0  3    23