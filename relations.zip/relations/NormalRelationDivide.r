RelationDiv
C(F) D(I) E(I)
2.0  3    5
N    3    9
2.0  3    7