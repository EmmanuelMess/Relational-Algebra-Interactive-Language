RelationB
A(S)     B(I) C(F) D(I) E(I)
"No"     1    2.0  3    1000
"Nombre"     1    2.0  3    1000