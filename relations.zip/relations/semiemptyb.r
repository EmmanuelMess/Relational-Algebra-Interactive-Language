SemiemptyB

A(I) B(F) C(S)