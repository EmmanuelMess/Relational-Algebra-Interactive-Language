AAAñññÑÑljflsdjkf
A(S)     B(I)     C(F) D(I) E(I)
"Nome" -1       -2.0  3    -5
"ññfdfd" 1         2.0  3    5
"Nombre" 1         2e3  3    5
"Nre" 0         2.0  3    5
"Nomre" 100000000 2.0  3    5
"Nombe" 5656      2.0  3    5
"Nore" 4444      2.0  N    5
"Nombre" 16565     2.0  3    5